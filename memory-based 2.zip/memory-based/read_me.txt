
Programming Language Used :- Python

Dataset :- http://labrosa.ee.columbia.edu/millionsong/sites/default/files/challenge/train_triplets.txt.zip
(It can be downloaded from the above link, it is a 3 GB zip file)

Algorithms :- In total there are three algorithms,

	Model Based :- 
				Step 1: run pruning.py , the output will be generated in train_triplets_concise.txt file
				Step 2: after step 1 is completed, i.e. train_triplets_concise.txt got generated, run CF_run.py and the 					   output of will be shown in console.

	User Based :- run user_based_cf.py , the output will be generated in User_based_output.txt file 

	
	Song Based :- run song_based_cf.py , the output will be generated in Song_based_output.txt file
